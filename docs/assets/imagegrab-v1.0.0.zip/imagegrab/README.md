# 图提取 ImageGrab · Chrome 电商图片提取下载插件

在淘宝 / 天猫、京东、拼多多商家版的商品详情页一键提取页面里所有商品图，
在新标签页集中预览、勾选，批量下载并统一转换为 **PNG** 格式。

- 浏览器：Chrome / Edge（Chromium 内核，最低 Chrome 102）
- 技术栈：Manifest V3 + 原生 JS（content script、Service Worker、OffscreenCanvas、chrome.downloads）
- 目录：`docs/` 是插件的静态官网（可直接部署到 GitHub Pages）

---

## 一、目录结构

```
imagegrab/
├── manifest.json          # MV3 清单：权限、注入规则、Service Worker
├── content.js             # 注入「获取图片」悬浮按钮 + 扫描页面图片
├── content.css            # 悬浮按钮样式（全部收在 #imagegrab-widget 下）
├── background.js          # Service Worker：存结果、开画廊、转 PNG、批量下载
├── gallery.html           # 新标签页画廊
├── gallery.js             # 画廊逻辑：勾选、筛选、进度、下载
├── gallery.css            # 画廊样式（响应式网格）
├── icons/                 # 扩展图标 16/48/128
├── docs/                  # 插件官网（纯静态，双击即可看）
│   ├── index.html
│   ├── css/style.css
│   ├── js/main.js
│   └── assets/            # favicon + 插件压缩包
└── README.md
```

## 二、安装（30 秒）

1. 解压 `imagegrab.zip` 到固定目录，例如 `D:\extensions\imagegrab`（之后不要移动或删除）。
2. Chrome 地址栏输入 `chrome://extensions` 回车（Edge 用 `edge://extensions`）。
3. 打开右上角 **开发者模式**。
4. 点 **加载已解压的扩展程序**，选择解压出来的 `imagegrab` 文件夹。
5. 建议把图标固定到工具栏，方便查看。

> 改完代码后，回到扩展页点一下该扩展卡片右下角的「刷新」按钮，再刷新商品页即可生效。

## 三、使用

1. 打开任意**商品详情页**（例如 `https://item.jd.com/100012043978.html`）。
2. 页面右下角出现悬浮按钮「获取图片」，点击。
3. 插件自动扫描 `<img>`、`srcset`、`data-src`、`data-lazy-src`、背景图等来源；
   图片太少时会自动向下滚动触发懒加载，再稍等 1～2 秒。
4. 扫描完成后自动打开新标签页「图提取」画廊：
   - 每张图显示缩略图、真实尺寸、复选框；
   - 顶部可改**文件名前缀**、按**最小尺寸**筛选、全选 / 反选；
   - 点「下载选中」开始批量下载，进度条实时显示。
5. 文件保存到浏览器默认下载目录，命名规则 `商品图_001.png`、`商品图_002.png`……

### 常见问题

| 现象 | 原因 / 处理 |
| --- | --- |
| 按钮不出现 | 只在详情页注入。列表页、首页、购物车不显示；另外确认扩展已启用并刷新页面。 |
| 图很少或没有 | 详情页图片是滚动懒加载的，先把页面往下滚一遍再点按钮；插件也会自动兜底滚动一次。 |
| 缩略图显示「加载失败」 | 部分 CDN 有防盗链，缩略图加载不出来，但下载时由扩展后台带权限 fetch，通常仍能成功。 |
| 下载的是「原图.jpg」 | 该图源不允许跨域读取（极少数），已自动降级为下载原图，不影响使用。 |
| 下载没有自动开始 | 检查是否开启了「每个文件都询问保存位置」，关闭后即可静默保存。 |

## 四、权限说明

| 权限 | 用途 |
| --- | --- |
| `activeTab` / `scripting` | 与当前商品页通信（手动触发时生效） |
| `downloads` | 调用 `chrome.downloads.download` 保存 PNG |
| `storage` | 把提取结果放到 `chrome.storage.local`，供画廊读取 |
| `host_permissions` | 覆盖三个平台域名 + 常见图片 CDN（alicdn / 360buyimg / pddpic 等），用于跨域 fetch 转码 |

所有图片处理都在本机完成，不上传任何数据。

## 五、官网（docs/）

- 本地预览：直接双击 `docs/index.html`。
- 部署：把整个仓库推到 GitHub，`Settings → Pages → Source: main / root`，
  再把 `docs/` 作为站点目录（或把 `docs` 内容放到仓库根）。
- 上线前记得替换 `docs/index.html` 里的两个占位链接：
  - 「下载插件」按钮 → `docs/assets/imagegrab-v1.0.0.zip`（已附带）或你的 Releases 地址；
  - 「查看源码」按钮 → 你的 GitHub 仓库地址。
- 改主色：只改 `docs/css/style.css` 顶部的 `--primary` 与 `--accent` 两个变量即可。

## 六、开发备注

- 图片转 PNG 走 `fetch` + `createImageBitmap` + `OffscreenCanvas`，绕开页面 canvas 的跨域污染问题；
- 文件名序号按导入顺序补零（001 起），与画廊里的预览名一致；
- 内容脚本用 1.5s 轮询 URL 变化，兼容淘宝 / 京东的 SPA 路由切换；
- 扫描结果按面积从大到小排序，最多保留 200 张，避免超大详情页卡顿。

### 无浏览器的冒烟测试

不想开浏览器也能先验证核心逻辑（过滤、绝对路径、文件名补零、进度回传、转码失败降级）：

```powershell
node test/smoke-test.js
```

脚本用最小 DOM 桩和 chrome API 桩分别跑 `content.js` 与 `background.js`，22 项断言全过即说明主流程正常。
真实效果仍以浏览器实测为准（见第三节自测清单）。
